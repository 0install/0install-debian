type t = [ A of int | B of t ];
type t2 = [ A of int | B of t ];
type t3 = [ A of int | B of t ];
