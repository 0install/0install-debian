value f ~a:_ ?b:_ = ();
