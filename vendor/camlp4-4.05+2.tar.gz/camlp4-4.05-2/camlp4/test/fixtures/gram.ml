EXTEND G expr: [[ l = LIST0 STRING -> l ]]; END;
EXTEND G expr: [[ l = LIST0 [ x = STRING -> x ] -> l ]]; END;
