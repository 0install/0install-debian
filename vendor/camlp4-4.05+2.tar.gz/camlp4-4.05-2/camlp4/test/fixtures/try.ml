try
  let f = Sys.getenv "CAMLP4_DEBUG_FILE"
  in
    foo bar foo bar foo bar foo bar foo bar foo bar foo bar foo bar foo bar foo bar foo bar foo bar
with Not_found -> stderr
