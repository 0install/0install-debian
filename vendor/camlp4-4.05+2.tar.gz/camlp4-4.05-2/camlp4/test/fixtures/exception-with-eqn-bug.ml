exception Foo of string = Bar
